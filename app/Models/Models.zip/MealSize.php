<?php

namespace App\Models;



class MealSize extends MyModel
{
      protected $table = "meal_sizes";
}
