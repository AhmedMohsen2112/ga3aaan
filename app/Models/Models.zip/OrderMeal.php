<?php

namespace App\Models;



class OrderMeal extends MyModel
{
    protected $table = "order_meals";

    public function order_meal_toppings()
    {
    	return $this->hasMany(OrderMealTopping::class,'order_meal_id');
    }

    public function meal()
    {
        return $this->belongsTo(Meal::class,'meal_id');
    }

    public static function transform($item)
    {
        $titleSlug = 'title_'.static::getLangCode();
        $transformer = new \stdclass();
        $transformer->meal = $item->meal->$titleSlug;
        $transformer->quantity =  $item->quantity;
        $transformer->total_price =  $item->cost_of_quantity;

        return $transformer;
    }

     protected static function boot() {
        parent::boot();

        static::deleting(function($order_meal) {
        	foreach ($order_meal->order_meal_toppings as $item) {
        		$item->delete();
        	}
        });
    }
}
