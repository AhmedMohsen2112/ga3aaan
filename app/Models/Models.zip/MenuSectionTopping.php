<?php

namespace App\Models;



class MenuSectionTopping extends MyModel
{
      protected $table = "menu_section_toppings";
      protected $hidden = array('pivot');
}
