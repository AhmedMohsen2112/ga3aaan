<?php

namespace App\Models;



class Address extends MyModel
{
   
    public static function  transform($item)
    {
       
        $transformer = new Address();
        $transformer->id = $item->id;
        $transformer->city = $item->city;
        $transformer->region = $item->region;
        $transformer->sub_region = $item->sub_region;
        $transformer->street = $item->street;
        $transformer->building_number = $item->building_number;
        $transformer->floor_number = $item->floor_number;
        $transformer->apartment_number = $item->apartment_number;
        $transformer->special_sign = $item->special_sign;
        $transformer->extra_info = $item->extra_info;
        
        return $transformer;

    }



    
}
