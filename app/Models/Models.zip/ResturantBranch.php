<?php

namespace App\Models;

class ResturantBranch extends MyModel
{
	protected $table = "resturant_branches";
}
