<?php

namespace App\Models;

use DB;

class Meal extends MyModel {

    protected $table = "meals";

    public function sizes() {
        return $this->belongsToMany(Size::class, 'meal_sizes', 'meal_id', 'size_id')->withPivot('id', 'price');
    }

    public function menu_section() {
        return $this->belongsTo(MenuSection::class);
    }

    public function favourites() {
        return $this->belongsToMany(User::class, 'favourites', 'meal_id', 'user_id');
    }

    public function toppings() {
        return $this->belongsToMany(MenuSectionTopping::class, 'meal_toppings', 'meal_id', 'menu_section_topping_id')->withPivot('id');
    }

    protected static function transformCollection($items, $type = null) {

        $transformers = array();

        if ($type == null) {
            $transform = 'transform';
        } else {
            $transform = 'transform' . $type;
        }
        if (count($items)) {

            $discount = static::getDiscount($items[0]);

            $user = static::auth_user();

            foreach ($items as $item) {

                $transformers[] = self::$transform($item, $discount, $user);
            }
        }

        return $transformers;
    }

    public static function transform($item, $user) {
        $discount = static::getDiscount($item);
        $titleSlug = 'title_' . static::getLangCode();
        $descriptionSlug = 'description_' . static::getLangCode();

        $transformer = new \stdClass();
        $transformer->id = $item->id;
        $transformer->title = $item->$titleSlug;
        $transformer->description = $item->$descriptionSlug;


        $transformer->price = $item->price;
        if ($discount != 0) {
            $transformer->discount_price = $item->price - (($item->price * $discount) / 100);
        }

        $transformer->image = url('public/uploads/meals') . '/' . $item->image;

        if ($item->sizes) {
            $counter = 0;
            $sizes = array();
            if ($discount != 0) {
                $transformer->sizes = $item->sizes()->select('meal_sizes.id', 'meal_sizes.price', 'sizes.' . $titleSlug . ' as size', DB::raw('( meal_sizes.price - ( (meal_sizes.price * ' . $discount . ') / 100 ) ) as discount_price')
                        )->get();
            } else {
                $transformer->sizes = $item->sizes()->select('meal_sizes.id', 'meal_sizes.price', 'sizes.' . $titleSlug . ' as size')->get();
            }
        }

        if ($item->toppings) {
            $transformer->toppings = $item->toppings()->join('toppings', 'menu_section_toppings.topping_id', '=', 'toppings.id')->select('meal_toppings.id', 'menu_section_toppings.price', 'toppings.' . $titleSlug . ' as topping')->get()->toArray();
        } else {
            $transformer->toppings = array();
        }


        if ($user != null) {
            $transformer->is_favourite = $user->favourites->contains($item->id) == true ? 1 : 0;
        } else {
            $transformer->is_favourite = 0;
        }
        $transformer->service_charge = $item->service_charge;
        $transformer->vat = $item->vat;
        $transformer->delivery_cost = $item->delivery_cost;
        $transformer->payment_methods = PaymentMethod::transformCollection($item->menu_section->resturant->payment_methods);
        return $transformer;
    }

    public static function transformForPagination($item) {
        $discount = static::getDiscount($item);
        $titleSlug = 'title_' . static::getLangCode();
        $descriptionSlug = 'description_' . static::getLangCode();

        $transformer = new \stdClass();
        $transformer->id = $item->id;
        $transformer->title = $item->$titleSlug;
        $transformer->description = $item->$descriptionSlug;
        $transformer->slug = $item->slug;
        $transformer->resturant_slug = $item->resturant_slug;
        $transformer->menu_section_slug = $item->menu_section_slug;


        $transformer->price = $item->price;
        if ($discount != 0) {
            $transformer->discount_price = $item->price - (($item->price * $discount) / 100);
        } else {
            $transformer->discount_price = 0;
        }

        $transformer->image = url('public/uploads/meals') . '/' . $item->image;

        $transformer->is_favourite = $item->favorite_id != null ? true : false;

        
        return $transformer;
    }

    public static function transformForDetails($item) {

        $discount = static::getDiscount($item);
        $titleSlug = 'title_' . static::getLangCode();
        $descriptionSlug = 'description_' . static::getLangCode();

        $transformer = new \stdClass();
        $transformer->id = $item->id;
        $transformer->title = $item->$titleSlug;
        $transformer->description = $item->$descriptionSlug;
        $transformer->slug = $item->slug;
        $transformer->resturant_slug = $item->resturant_slug;
        $transformer->menu_section_slug = $item->menu_section_slug;


        $transformer->price = $item->price;
        if ($discount != 0) {
            $transformer->discount_price = $item->price - (($item->price * $discount) / 100);
        }

        $transformer->image = url('public/uploads/meals') . '/' . $item->image;

        $transformer->is_favourite = $item->favorite_id != null ? true : false;
        $transformer->sizes = $item->sizes()->select('meal_sizes.id', 'meal_sizes.price', 'sizes.' . $titleSlug . ' as size', DB::raw("( meal_sizes.price - ( (meal_sizes.price * $discount) / 100 ) ) as discount_price"))->get();
        $transformer->toppings = $item->toppings()->join('toppings', 'menu_section_toppings.topping_id', '=', 'toppings.id')->select('meal_toppings.id', 'menu_section_toppings.price', 'toppings.' . $titleSlug . ' as topping')->get();
        
        return $transformer;
    }

    public static function transformMenu_section($item, $discount, $user) {
        $titleSlug = 'title_' . static::getLangCode();

        $transformer = new \stdClass();
        $transformer->id = $item->id;
        $transformer->title = $item->$titleSlug;
        $transformer->price = $item->price;
        if ($discount != 0) {
            $transformer->discount_price = $item->price - (($item->price * $discount) / 100);
        }
        $transformer->image = url('public/uploads/meals') . '/' . $item->image;
        if ($user != null) {
            $transformer->is_favourite = $user->favourites->contains($item->id) == true ? 1 : 0;
        } else {
            $transformer->is_favourite = 0;
        }
        return $transformer;
    }

    private static function getDiscount($meal) {
        $offer = $meal->menu_section->resturant->offer;
        $discount = 0;
        if ($offer) {
            if ($offer->type == 1) {
                $discount = $offer->discount;
            } elseif ($offer->type == 2) {
                $menu_sections = explode(",", $offer->menu_section_ids);
                if (!in_array($meal->menu_section->id, $menu_sections)) {
                    $discount = $offer->discount;
                }
            } elseif ($offer->type == 3) {
                $menu_sections = explode(",", $offer->menu_section_ids);
                if (in_array($meal->menu_section->id, $menu_sections)) {
                    $discount = $offer->discount;
                }
            }
        }
        return $discount;
    }

    protected static function boot() {
        parent::boot();

        static::deleting(function($meal) {
            $meal->sizes->detach();
        });
    }

}
