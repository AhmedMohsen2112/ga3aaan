<?php

namespace App\Models;



class Topping extends MyModel
{
      
}
