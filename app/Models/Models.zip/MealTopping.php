<?php

namespace App\Models;

class MealTopping extends MyModel
{
    protected $table = "meal_toppings";
}
