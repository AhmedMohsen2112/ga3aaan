<?php

namespace App\Models;

use DateTime;

class Resturant extends MyModel {

    protected $table = "resturantes";
    public static $sizes = array(
        's' => array('width' => 110, 'height' => 110)
    );
    public static $week_days = [
        ['title' => 'saturday', 'name' => 'Sat'], ['title' => 'sunday', 'name' => 'Sun'], ['title' => 'monday', 'name' => 'Mon'],
        ['title' => 'tuesday', 'name' => 'Tue'], ['title' => 'wednesday', 'name' => 'Wed'], ['title' => 'thursday', 'name' => 'Thu'],
        ['title' => 'friday', 'name' => 'Fri']
    ];

    public function payment_methods() {
        return $this->belongsToMany(PaymentMethod::class, 'resturant_payment_methods', 'resturant_id', 'payment_method_id');
    }

    public function cuisines() {
        return $this->belongsToMany(Cuisine::class, 'resturant_cuisines', 'resturant_id', 'cuisine_id');
    }

    public function branches() {
        return $this->hasMany(ResturantBranch::class);
    }

    public function active_menu_sections() {
        return $this->hasMany(MenuSection::class)->where('active', true)->orderBy('this_order');
    }

    public function offer() {
        return $this->hasOne(Offer::class)->where('active', true)->where('available_until', '>', date('Y-m-d'));
    }

    public function rates() {
        return $this->hasMany(Rate::class);
    }

    public function hasVisa() {
        return $this->payment_methods->contains(2);
    }

    public static function transform($item) {
        $titleSlug = "title_" . static::getLangCode();

        $transformer = new Resturant;
        $transformer->id = $item->id;
        $transformer->name = $item->{$titleSlug} . '-' . $item->region;
        $transformer->slug = $item->slug;
        $transformer->branch_id = $item->branch_id;
        $transformer->image = url('public/uploads/resturantes') . '/' . $item->image;
        $transformer->delivery_time = $item->delivery_time;
        $transformer->delivery_cost = ceil($item->delivery_cost);
        $transformer->minimum_charge = ceil($item->minimum_charge);
        $transformer->rate = $item->rate;
        if ($item->options == 1) {
            $transformer->is_new = 1;
            $transformer->is_ad = 0;
        } elseif ($item->options == 2) {
            $transformer->is_ad = 1;
            $transformer->is_new = 0;
        }
        $transformer->hasVisa = $item->hasVisa() == true ? 1 : 0;
        $transformer->has_offer = $item->has_offer;
        $transformer->working_hours = json_decode($item->working_hours);
        $transformer->is_open = self::checkIsOpen(json_decode($item->working_hours)) == true ? 1 : 0;
        $transformer->num_of_raters = $item->rates()->count();
        $transformer->vat = $item->vat;
        $transformer->service_charge = ceil($item->service_charge);

        $transformer->menu_sections = MenuSection::transformCollection($item->active_menu_sections);
        $transformer->cuisines = Cuisine::transformCollection($item->cuisines);
        $transformer->payment_methods = PaymentMethod::transformCollection($item->payment_methods);
        if ($item->offer) {
            $transformer->has_offer = 1;
            $transformer->offer = Offer::transform($item->offer);
        }
        $transformer->rates = Rate::transformCollection($item->rates);

        return $transformer;
    }

    public static function transformOne($item) {
        $titleSlug = "title_" . static::getLangCode();

        $transformer = new Resturant;
        $transformer->id = $item->id;
        $transformer->name = $item->{$titleSlug} . '-' . $item->region_title;
        $transformer->slug = $item->slug;
        $transformer->image = url("public/uploads/resturantes/$item->image");

        $transformer->minimum_charge = $item->minimum_charge;
        $transformer->rate = $item->rate;
        if ($item->options == 1) {
            $transformer->is_new = 1;
            $transformer->is_ad = 0;
        } elseif ($item->options == 2) {
            $transformer->is_ad = 1;
            $transformer->is_new = 0;
        }
        $transformer->hasVisa = $item->hasVisa() == true ? 1 : 0;

        $transformer->has_offer = ($item->offers > 0) ? true : false;
        $transformer->working_hours = json_decode($item->working_hours);
        $transformer->is_open = self::checkIsOpen(json_decode($item->working_hours)) == true ? 1 : 0;
        $transformer->num_of_raters = $item->rates()->count();
        $transformer->vat = ceil($item->vat);
        $transformer->service_charge = ceil($item->service_charge);
        $transformer->delivery_time = $item->delivery_time;
        $transformer->delivery_cost = ceil($item->delivery_cost);
        $transformer->cuisines = Cuisine::transformCollection($item->cuisines);


        return $transformer;
    }

    private static function checkIsOpen($working_days) {
        $day = date("D");
        if (isset($working_days->{$day})) {
            $currentTime = new DateTime();
            $startTime = new DateTime($working_days->{$day}->from);
            $endTime = new DateTime($working_days->{$day}->to);
            if ($currentTime >= $startTime && $currentTime <= $endTime) {
                return true;
            }
        }
        return false;
    }

}
