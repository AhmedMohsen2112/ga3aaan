<?php

namespace App\Models;

class Coupon extends MyModel
{
      
}
