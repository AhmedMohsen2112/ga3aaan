<?php

namespace App\Models;
use Carbon\Carbon;


class Order extends MyModel
{
     public function getCreatedAtAttribute($attr) {        
       return Carbon::parse($attr)->format('Y/m/d');
    }

      public function order_meals()
      {
      	return $this->hasMany(OrderMeal::class,'order_id');
      }

      public function address()
      {
        return $this->belongsTo(Address::class,'user_address_id');
      }
     

      public static function transform($item)
      {
        $transformer = new \stdClass();
        $transformer->id = $item->id;
        $transformer->resturant = $item->resturant;
        $transformer->region = $item->region;
        $transformer->user_address = Address::transform($item->address);
        $transformer->toppings_price = $item->toppings_price;
        $transformer->service_charge = $item->service_charge;
        $transformer->vat = $item->vat;
        $transformer->delivery_cost = $item->delivery_cost;
        $transformer->primary_price = $item->primary_price;
        $transformer->total_cost = $item->total_cost;
        if ($item->coupon) {
           $transformer->coupon = $item->coupon;
        }
        else{
          $transformer->coupon = "";
        }

        $transformer->meals = OrderMeal::transformCollection($item->order_meals);
        $transformer->status = $item->status; 
        if ($item->status == 0) {
           $transformer->status_text = _lang('app.pending');
        }
        elseif($item->status == 1){
           $transformer->status_text = _lang('app.order_processing_is_ongoing');
        }
        elseif($item->status == 2){
           $transformer->status_text = _lang('app.order_is_being_delivered');
        }
        elseif($item->status == 3){
            $transformer->status_text = _lang('app.order_was_deliverd');
        }
        elseif($item->status == 4){
            $transformer->status_text = _lang('app.order_was_rejected');
        }
        $transformer->is_rated = $item->is_rated;
        $transformer->date = $item->created_at;

        return $transformer;
      }

        protected static function boot() {
        parent::boot();

        static::deleting(function($order) {
        	foreach ($order->order_meals as $item) {
        		$item->delete();
        	}
        });
    }
}
