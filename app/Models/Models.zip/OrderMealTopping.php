<?php

namespace App\Models;

class OrderMealTopping extends MyModel
{
    protected $table = "order_meal_toppings";
}
