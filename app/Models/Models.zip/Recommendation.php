<?php

namespace App\Models;

class Recommendation extends MyModel
{

}
