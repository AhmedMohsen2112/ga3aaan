<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use App\Models\Meal;
use App\Models\MenuSection;
use App\Models\Resturant;
use App\Models\Coupon;
use App\Models\Order;
use App\Models\OrderMeal;
use App\Models\OrderMealTopping;
use App\Models\Rate;
use Validator;
use DB;

class OrdersController extends ApiController {

    private $rate_rules = array(
        'order_id' => 'required',
        'rate' => 'required',
    );

    private $order_rules = array(
        'order' => 'required',
    );


    public function __construct() {
        parent::__construct();
    }
    

    public function index(Request $request) {
      
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), $this->order_rules);
        if ($validator->fails()) {
            $errors = $validator->errors()->toArray();
            return _api_json('', ['errors' => $errors],422);
        }
        DB::beginTransaction();
        try {

           $order = json_decode($request->order);
           $user = $this->auth_user();
           $resturnat = Resturant::find($order->order_info->resturant_id);
           $coupon = "";
            //checking coupon
           if ($order->order_info->coupon) {
            $coupon =  Coupon::where('coupon',$order->order_info->coupon)
            ->where(function ($query) {
             $query->where('resturant_id',$resturnat->id)
                  ->orWhere('resturant_id', null);
         })
            ->where('available_until','>=',date('Y-m-d'))
            ->first();
        }
        
        if ($request->order_id) {

            $newOrder = Order::find($request->order_id);
             if (!$newOrder) {
                $message = _lang('app.not_found');
                return _api_json('', ['message' => $message],404);
            }
            foreach ( $newOrder->order_meals as $item) {
                $item->delete();
            }
           
        }
        else{

            //creating new order
            $newOrder = $this->createOrder($user,$resturnat,$order,$coupon);
        }

        //add order meals
        foreach ($order->order_detailes as $meal) {
            $order_meal = $this->createOrderMeal($newOrder,$meal);
            if (count($meal->toppings) > 0) {
                foreach ($meal->toppings as $topping) {
                    $this->createOrderTopping($order_meal,$topping);
                }  
            }       
        }

        DB::commit();
        $message = _lang('app.your_request_has_been_sent_successfully');
        return _api_json('',['message' => $message]);
        } catch (\Exception $e) {
            //dd($e);
            DB::rollback();
           
            $message = _lang('app.error_is_occured');
           // $message = $e->getMessage();
            return _api_json('', ['message' => $message],422);
        }
    }

    public function show($id)
    {
        try {
            $user = $this->auth_user();
        $order = Order::join('resturantes','orders.resturant_id','=','resturantes.id')
             ->join('resturant_branches','resturant_branches.id','=','orders.resturant_branch_id')
            ->join('cities','resturant_branches.region_id','=','cities.id')
            ->select('orders.*','resturantes.title_'.$this->lang_code.' as resturant','resturantes.image','cities.title_'.$this->lang_code.' as region')
        ->where('orders.id',$id)
        ->where('orders.user_id',$user->id)
        ->first();
        if (!$order) {
            $message = _lang('app.not_found');
            return _api_json(new \stdClass(), ['message' => $message],404);
        }

        return _api_json(Order::transform($order));
            
        } catch (\Exception $e) {
            dd($e);
            $message = _lang('app.error_is_occured');
            return _api_json(new \stdClass(), ['message' => $message],422);
        }
        
    }
    public function destroy($id)
    {
        try {

            $order = Order::find($id);
            if (!$order) {
                $message = _lang('app.not_found');
                return _api_json('', ['message' => $message],404);
            }
            $order->delete();
            $message = _lang('app.canceled_successfully');
            return _api_json('');
            
        } catch (\Exception $e) {
            $message = _lang('app.error_is_occured');
            return _api_json('', ['message' => $message],422);
        }
    }

    public function cart($id)
    {
        try {

        $order = Order::find($id);
        if (!$order) {
            $message = _lang('app.not_found');
            return _api_json('', ['message' => $message],404);
        }

        $order_json = new \stdClass();

        $meals = array();
        $order_info = $this->jsonCreatOrderInfo($order);

       
        $order_meals = OrderMeal::where('order_id',$id)
        ->join('meals','order_meals.meal_id','=','meals.id')
        ->leftJoin('meal_sizes','order_meals.meal_size_id','=','meal_sizes.id')
        ->leftJoin('sizes','meal_sizes.size_id','=','sizes.id')
        ->select('order_meals.*','meals.title_'.$this->lang_code.' as meal_title','sizes.title_'.$this->lang_code.' as size_title')
        ->get();

        foreach ($order_meals as $order_meal) {
                
                $meal = $this->jsonCreatMeal($order_meal);
                if ($order_meal->order_meal_toppings) {
                    $toppings = array();
                    foreach ($order_meal->order_meal_toppings as $meal_topping)
                    {
                        $topping = $this->jsonCreatTopping($meal_topping);  
                        array_push($toppings,$topping);
                    }
                    $meal->toppings = $toppings;
                }
                else{
                    $meal->toppings = $toppings;
                }
                 array_push($meals,$meal);
        }
                $order_json->order_detailes =  $meals;
                $order_json->order_info =  $order_info;

        return _api_json($order_json);
            
        } catch (\Exception $e) {
           
            $message = _lang('app.error_is_occured');
            return _api_json('', ['message' => $message],422);
        }
        
    }

    public function rate(Request $request)
    {
          DB::beginTransaction();
         try {
            $validator = Validator::make($request->all(), $this->rate_rules);
            if ($validator->fails()) {
            $errors = $validator->errors()->toArray();
            return _api_json('', ['errors' => $errors],422);
            }
            $order = Order::find($request->order_id);
            if (!$order) {
                $message = _lang('app.not_found');
                return _api_json('', ['message' => $message],404);
            }
           $user = $this->auth_user();
           $rate = new Rate;
           $rate->user_id = $user->id;
           $rate->resturant_id =  $order->resturant_id;
           $rate->order_id = $order->id;
           $rate->rate = $request->rate;
           if ($request->opinion) {
               $rate->opinion = $request->opinion;
           }
           $rate->save();
           $order->is_rated = true;
           $order->save();
           
           $resturant_rate = Rate::where('resturant_id',$order->resturant_id)
                                     ->select(DB::raw(' SUM(rate)/COUNT(*) as rate'))
                                     ->first();

           $resturant = Resturant::find($order->resturant_id);
           $resturant->rate =  $resturant_rate;
           $resturant->save();
           

           DB::commit();
           $message = _lang('app.rated_successfully');
           return _api_json('',['message' =>  $message]);
            
        } catch (\Exception $e) {
            dd($e);
            DB::rollback();
            $message = _lang('app.error_is_occured');
            return _api_json('', ['message' => $message],422);
        }
    }
    

   private function jsonCreatOrderInfo($order){

        $order_info = new \stdClass();
        $order_info->resturant_id = $order->resturant_id;
        $order_info->resturant_branch_id = $order->resturant_branch_id;
        $order_info->user_address_id = $order->user_address_id;
        $order_info->payment_method_id = $order->payment_method_id;
        $order_info->primary_price = $order->primary_price;
        $order_info->toppings_price = $order->toppings_price;
        $order_info->service_charge = $order->service_charge;
        $order_info->vat = $order->vat;
        $order_info->delivery_cost = $order->delivery_cost;
        $order_info->total_cost = $order->total_cost;
        $order_info->net_cost = $order->net_cost;
        $order_info->phone = $order->phone;
        $order_info->coupon = $order->coupon;
        

        return $order_info;

   }

   private function jsonCreatMeal($order_meal){
        $meal = new \stdClass();
        $meal->id = $order_meal->meal_id;
        $meal->size_id = $order_meal->meal_size_id;
        $meal->quantity = $order_meal->quantity;
        $meal->price    = $order_meal->cost_of_meal;
        $meal->total_price = $order_meal->cost_of_quantity;
        $meal->comment = $order_meal->comment;
        $meal->meal_title = $order_meal->meal_title;
        $meal->size_title = $order_meal->size_title;
        return $meal;
   }

    private function jsonCreatTopping($meal_topping){

        $topping = new \stdClass();
        $topping->id         = $meal_topping->meal_topping_id;
        $topping->quantity   = $meal_topping->quantity;
        $topping->price      = $meal_topping->cost_of_topping;
        $topping->total_price = $meal_topping->cost_of_quantity;

        return $topping;

   }



    private function createOrder($user,$resturnat,$order,$coupon){
        $newOrder = new Order;
        $newOrder->user_id = $user->id;
        $newOrder->resturant_id = $resturnat->id;
        $newOrder->resturant_branch_id = $order->order_info->resturant_branch_id;
        $newOrder->user_address_id = $order->order_info->user_address_id;
        $newOrder->payment_method_id = $order->order_info->payment_method_id;
        
        $newOrder->primary_price = $order->order_info->primary_price;
        $newOrder->service_charge = $order->order_info->service_charge;
        $newOrder->vat = $order->order_info->vat;
        $newOrder->delivery_cost = $order->order_info->delivery_cost;
        $newOrder->total_cost = $order->order_info->total_cost;
        
        $newOrder->phone = $order->order_info->phone;

        if ($order->order_info->coupon) {
            $newOrder->coupon = $coupon->coupon;
            $newOrder->coupon_discount = $coupon->discount;
        }
        $newOrder->net_cost = $order->order_info->net_cost;
        $newOrder->status = 0;
        $newOrder->commission =  $resturnat->commission;
        $newOrder->toppings_price = $order->order_info->toppings_price;
        $newOrder->save();

        return $newOrder;
    }

    private function createOrderMeal($newOrder,$meal){


        $order_meal = new OrderMeal;
        $order_meal->order_id = $newOrder->id;
        $order_meal->meal_id  = $meal->id;
        $order_meal->meal_size_id  = $meal->size_id;
        $order_meal->quantity = $meal->quantity;
        $order_meal->cost_of_meal = $meal->price;
        $order_meal->cost_of_quantity = $meal->total_price;
        $order_meal->toppings_price = $meal->toppings_price;
        $order_meal->comment = $meal->comment;

        $order_meal->save();
        
        return $order_meal;
    }

    private function createOrderTopping($order_meal,$topping){

        $order_meal_topping = new OrderMealTopping;
        $order_meal_topping->order_meal_id = $order_meal->id;
        $order_meal_topping->meal_topping_id = $topping->id;
        $order_meal_topping->quantity = $topping->quantity;
        $order_meal_topping->cost_of_topping = $topping->price;
        $order_meal_topping->cost_of_quantity = $topping->total_price;

        $order_meal_topping->save();
    }


}
