<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiController;
use App\Models\Meal;
use App\Models\MenuSection;
use Validator;
use DB;

class MealsController extends ApiController {
    
    private $rules = array(
        'menu_section' => 'required',
    );

     private $meal_rules = array(
        'city' => 'required',
        'region' => 'required',
        'resturant' => 'required'
    );

    public function __construct() {
        parent::__construct();
    }
    

    protected function index(Request $request) {
        
        $meals = array();
        $validator = Validator::make($request->all(), $this->rules);
        if ($validator->fails()) {
            $errors = $validator->errors()->toArray();
            return _api_json($meals, ['errors' => $errors], 422);
        } else {
            try {
                
                $meals = Meal::where('menu_section_id',$request->menu_section)
                             ->where('active',true)
                             ->orderBy('this_order')
                             ->paginate($this->limit);

                $meals = Meal::transformCollection($meals,'Menu_section');
                return _api_json($meals);
            } catch (\Exception $e) {
                //dd($e);
                $message = _lang('app.error_is_occured');
                return _api_json($meals, ['message' => $message],422);
            }
        }
    }

    public function show(Request $request,$id)
    {
      
        try {
            $validator = Validator::make($request->all(), $this->meal_rules);
            if ($validator->fails()) {
                $errors = $validator->errors()->toArray();
                return _api_json(new \stdClass(), ['errors' => $errors], 422);
            }
            $user = $this->auth_user();
            $meal = Meal::join('menu_sections','meals.menu_section_id','=','menu_sections.id')
            ->join('resturantes','menu_sections.resturant_id','=','resturantes.id')
            ->join('resturant_branches','resturant_branches.resturant_id','=','resturantes.id')
            ->where('resturantes.id',$request->resturant)
            ->where('resturant_branches.city_id',$request->city)
            ->where('resturant_branches.region_id',$request->region)
            ->where('meals.id',$id)
            ->where('meals.active',true)
            ->select('meals.*','resturantes.service_charge','resturantes.vat','resturant_branches.delivery_cost')
            ->first();
            if (!$meal) {
                $message = _lang('app.not_found');
                return _api_json(new \stdClass(), ['message' => $message],404);
            }              
            $meal = Meal::transform($meal,$user);
            return _api_json($meal);
            } catch (\Exception $e) {
                dd($e);
                $message = _lang('app.error_is_occured');
                return _api_json(new \stdClass(), ['message' => $message],422);
            }
        
    }

    public function addDeleteFavourite($meal_id)
    {
        try {
            $user = $this->auth_user();
            $Meal = Meal::find($meal_id);
            if (!$Meal) {
                $message = _lang('app.not_found');
                return _api_json('', ['message' => $message], 404);
            }

            if ($user->favourites->contains($meal_id)) {
                $user->favourites()->detach($Meal->id);
            }
            else{
                $user->favourites()->attach($Meal);
            }
            return _api_json('');
        } catch (\Exception $e) {
            $message = _lang('app.error_is_occured');
            return _api_json('', ['message' => $e->getMessage()],422);
        }
    }

 

   

}
